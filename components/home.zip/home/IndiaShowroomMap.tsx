"use client";

import { useEffect, useState } from "react";
import India from "@svg-maps/india";

type ShowroomLocation = {
  city: string;
  x: number;
  y: number;
};

const locations: ShowroomLocation[] = [
  {
    city: "Delhi",
    x: 53,
    y: 14,
  },
  {
    city: "Jaipur",
    x: 39,
    y: 29,
  },
  {
    city: "Ahmedabad",
    x: 31,
    y: 43,
  },
  {
    city: "Mumbai",
    x: 36,
    y: 58,
  },
  {
    city: "Pune",
    x: 43,
    y: 62,
  },
  {
    city: "Hyderabad",
    x: 51,
    y: 64,
  },
  {
    city: "Bengaluru",
    x: 48,
    y: 78,
  },
  {
    city: "Chennai",
    x: 59,
    y: 79,
  },
  {
    city: "Kochi",
    x: 44,
    y: 89,
  },
  {
    city: "Kolkata",
    x: 73,
    y: 49,
  },
];

export default function IndiaShowroomMap() {
  const [activeIndex, setActiveIndex] = useState(0);

  const activeLocation = locations[activeIndex];

  useEffect(() => {
    const interval = window.setInterval(() => {
      setActiveIndex((current) => {
        return (current + 1) % locations.length;
      });
    }, 3500);

    return () => window.clearInterval(interval);
  }, []);

  const previous = () => {
    setActiveIndex((current) =>
      current === 0 ? locations.length - 1 : current - 1
    );
  };

  const next = () => {
    setActiveIndex((current) =>
      current === locations.length - 1 ? 0 : current + 1
    );
  };

  return (
    <div className="relative h-full w-full">

      {/* =========================================================
          INDIA MAP
          ========================================================= */}
      <div
        className="
          absolute
          right-[5%]
          top-[5%]
          h-[82%]
          w-[72%]
          sm:right-[3%]
          sm:w-[75%]
          lg:right-[1%]
          lg:w-[76%]
        "
      >
        <svg
          viewBox={India.viewBox}
          className="h-full w-full"
          role="img"
          aria-label="Avalon showroom locations across India"
        >
          <g>
            {India.locations.map((location) => (
              <path
                key={location.id}
                d={location.path}
                className="
                  fill-[#eeeeee]
                  stroke-white
                  transition-colors
                  duration-500
                  hover:fill-[#e5e5e5]
                "
                strokeWidth="0.7"
              />
            ))}
          </g>
        </svg>
      </div>

      {/* =========================================================
          LOCATION PINS
          ========================================================= */}
      <div className="absolute inset-0">

        {locations.map((location, index) => {
          const active = index === activeIndex;

          return (
            <button
              key={location.city}
              type="button"
              aria-label={`Avalon showroom in ${location.city}`}
              onClick={() => setActiveIndex(index)}
              className="
                absolute
                z-10
                -translate-x-1/2
                -translate-y-1/2
                outline-none
              "
              style={{
                left: `${location.x}%`,
                top: `${location.y}%`,
              }}
            >
              {/* Pulse */}
              {active && (
                <span
                  className="
                    absolute
                    left-1/2
                    top-1/2
                    h-[14px]
                    w-[14px]
                    -translate-x-1/2
                    -translate-y-1/2
                    rounded-full
                    bg-avalon-red/30
                    animate-ping
                  "
                />
              )}

              {/* Pin */}
              <span
                className={`
                  relative
                  block
                  h-[9px]
                  w-[9px]
                  rounded-full
                  border-[1.5px]
                  border-white
                  bg-avalon-red
                  shadow-[0_1px_5px_rgba(0,0,0,0.2)]
                  transition-transform
                  duration-300
                  ${
                    active
                      ? "scale-[1.35]"
                      : "hover:scale-125"
                  }
                `}
              />
            </button>
          );
        })}
      </div>

      {/* =========================================================
          BLACK LOCATION TOOLTIP
          ========================================================= */}
      <div
        className="
          absolute
          bottom-[45px]
          right-[4%]
          z-30
          w-[155px]
          rounded-[10px]
          bg-[#171717]
          px-3
          py-2.5
          text-white
          shadow-[0_8px_24px_rgba(0,0,0,0.18)]
          sm:w-[165px]
          lg:w-[170px]
        "
      >
        <div className="flex items-center gap-2.5">

          {/* White location circle */}
          <div
            className="
              flex
              h-[29px]
              w-[29px]
              shrink-0
              items-center
              justify-center
              rounded-full
              bg-white
            "
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
            >
              <path
                d="M12 21s7-6.1 7-12a7 7 0 1 0-14 0c0 5.9 7 12 7 12Z"
                stroke="#171717"
                strokeWidth="2"
              />

              <circle
                cx="12"
                cy="9"
                r="2.2"
                stroke="#171717"
                strokeWidth="2"
              />
            </svg>
          </div>

          <div className="min-w-0">
            <p
              className="
                text-[9px]
                font-semibold
                leading-[1.2]
                sm:text-[10px]
              "
            >
              Pan India Presence
            </p>

            <p
              className="
                mt-[2px]
                text-[8px]
                leading-[1.2]
                text-white/70
                sm:text-[9px]
              "
            >
              {activeLocation.city === "Delhi"
                ? "Find Avalon near you"
                : `${activeLocation.city} showroom`}
            </p>
          </div>
        </div>
      </div>

      {/* =========================================================
          BOTTOM NAVIGATION
          ========================================================= */}
      <div
        className="
          absolute
          bottom-[4px]
          right-[4%]
          z-40
          flex
          items-center
          gap-2
        "
      >
        {/* Previous */}
        <button
          type="button"
          onClick={previous}
          aria-label="Previous showroom"
          className="
            flex
            h-[32px]
            w-[32px]
            items-center
            justify-center
            rounded-full
            border
            border-[#d9d9d9]
            bg-white
            text-[#444]
            transition-all
            duration-200
            hover:border-avalon-red
            hover:text-avalon-red
          "
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 16 16"
            fill="none"
          >
            <path
              d="M13 8H3M3 8L7 4M3 8L7 12"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        {/* Next */}
        <button
          type="button"
          onClick={next}
          aria-label="Next showroom"
          className="
            flex
            h-[32px]
            w-[32px]
            items-center
            justify-center
            rounded-full
            border
            border-avalon-red/40
            bg-white
            text-avalon-red
            transition-all
            duration-200
            hover:bg-avalon-red
            hover:text-white
          "
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 16 16"
            fill="none"
          >
            <path
              d="M3 8H13M13 8L9 4M13 8L9 12"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      </div>
    </div>
  );
}