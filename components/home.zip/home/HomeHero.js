import Image from "next/image";
import Link from "next/link";
import { assets } from "@/lib/assets";

export default function HomeHero() {
  return (
    <section className="hero-diagonal relative bg-white overflow-hidden">
      <div className="grid lg:grid-cols-[40%_60%] min-h-[520px] lg:min-h-[560px]">
        <div className="container-avalon lg:max-w-none lg:pl-[clamp(1rem,5.3vw,5rem)] lg:pr-8 flex flex-col justify-center py-12 lg:py-16 z-10">
          <span className="text-[11px] font-semibold tracking-[0.16em] text-gray-400 uppercase mb-4">
            Premium Sleep Solutions
          </span>
          <h1 className="font-serif text-[2.35rem] sm:text-5xl lg:text-[3.5rem] leading-[1.1] text-avalon-black mb-5 max-w-lg">
            Better Sleep.{" "}
            <span className="text-avalon-red block sm:inline">A Brighter Tomorrow.</span>
          </h1>
          <p className="text-gray-600 text-[15px] md:text-base leading-relaxed max-w-md mb-8">
            Thoughtfully designed mattresses and furniture for deeper sleep, better health and brighter days.
          </p>
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <Link
              href="/product-catalog"
              className="inline-flex items-center gap-2 rounded-full bg-avalon-red text-white px-7 py-3.5 text-sm font-semibold hover:bg-[#c9181f] transition-colors"
            >
              Explore Our Collection
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 8H13M13 8L9 4M13 8L9 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </Link>
            <Link
              href="/about"
              className="inline-flex items-center gap-2.5 text-sm font-semibold text-avalon-black hover:text-avalon-red transition-colors"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-avalon-black">
                <svg width="10" height="12" viewBox="0 0 10 12" fill="currentColor" aria-hidden="true">
                  <path d="M0 0v12l10-6L0 0z" />
                </svg>
              </span>
              Watch Our Story
            </Link>
          </div>
          <div className="flex items-center gap-3 text-xs font-medium tracking-[0.15em] text-gray-400">
            <span className="text-avalon-black">01</span>
            <span className="h-px w-8 bg-avalon-border" aria-hidden="true" />
            <span>03</span>
          </div>
        </div>

        <div className="relative min-h-[320px] lg:min-h-full">
          <Image
            src={assets.home.hero}
            alt="Premium Avalon mattress in a modern bedroom with mountain views"
            fill
            priority
            className="object-cover object-center"
            sizes="(max-width: 1024px) 100vw, 55vw"
          />
          <div
            className="absolute right-0 top-0 bottom-0 w-10 md:w-12 bg-avalon-red z-10 flex items-center justify-center"
            aria-hidden="true"
          >
            <p className="home-hero-strip text-white text-[9px] md:text-[10px] font-semibold tracking-[0.2em] uppercase">
              Rest · Recharge · Reimagine · A Brighter You
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
